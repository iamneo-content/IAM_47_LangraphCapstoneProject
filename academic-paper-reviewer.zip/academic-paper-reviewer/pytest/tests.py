#!/usr/bin/env python3
"""
Comprehensive Test Suite for Academic Paper Reviewer Pipeline

Tests all major components: agents, analyzers, nodes, workflow, graph, and state.

Run with: python tests.py
Or with pytest: pytest tests.py -v
"""

import os
import sys
import unittest
import logging
import tempfile
from typing import Dict, Any
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[logging.StreamHandler()]
)

logger = logging.getLogger("tests")

# Import the required modules
try:
    from config import get_config, get_config_value
    from state import ReviewState
    from graph import ReviewGraph
    from workflows.review_workflow import build_review_workflow

    # Import agents
    from agents.base_agent import BaseAgent
    from agents.citation_checker_agent import CitationCheckerAgent
    from agents.methodology_reviewer_agent import MethodologyReviewerAgent
    from agents.novelty_analyzer_agent import NoveltyAnalyzerAgent
    from agents.reproducibility_agent import ReproducibilityAgent
    from agents.writing_quality_agent import WritingQualityAgent
    from agents.coordinator_agent import CoordinatorAgent

    # Import analyzers
    from analyzers.citation_checker import CitationChecker
    from analyzers.methodology_reviewer import MethodologyReviewer
    from analyzers.novelty_analyzer import NoveltyAnalyzer
    from analyzers.reproducibility_analyzer import ReproducibilityAnalyzer
    from analyzers.writing_quality_analyzer import WritingQualityAnalyzer

    # Import nodes
    from nodes.citation_checker_node import citation_checker_node
    from nodes.methodology_reviewer_node import methodology_reviewer_node
    from nodes.novelty_analyzer_node import novelty_analyzer_node
    from nodes.reproducibility_node import reproducibility_node
    from nodes.writing_quality_node import writing_quality_node
    from nodes.decision_node import decision_node

except ImportError as e:
    logger.error(f"Import error: {e}")
    logger.error("Make sure you're running this test from the project root directory")
    sys.exit(1)


class TestAcademicPaperReviewerArchitecture(unittest.TestCase):
    """Test suite for Academic Paper Reviewer Architecture"""

    SAMPLE_PAPER = '''
# Abstract
This paper presents a novel approach to machine learning optimization using quantum computing principles.
The methodology involves combining classical gradient descent with quantum annealing techniques.

# Introduction
Machine learning has revolutionized data science [1]. Recent advances in quantum computing offer new opportunities [2].
Our approach builds on previous work in quantum optimization [3].

# Methodology
We implemented a hybrid classical-quantum algorithm. The algorithm uses the following steps:
1. Initialize parameters using classical methods
2. Apply quantum gates to create superposition states
3. Measure and update parameters based on quantum results
4. Iterate until convergence

The experimental setup consisted of a quantum simulator with 20 qubits.
We ran experiments with varying hyperparameters.

# Results
Our method achieved 95% accuracy on the test dataset, outperforming baseline methods by 10%.
The training time was reduced by 30% compared to classical approaches.

# Conclusion
This work demonstrates the potential of quantum-classical hybrid approaches for machine learning.
Future work will explore larger quantum systems and more complex datasets.

# References
[1] LeCun et al., "Deep Learning", Nature, 2015
[2] Preskill, "Quantum Computing in the NISQ era", Quantum, 2018
[3] Farhi et al., "Quantum Approximate Optimization Algorithm", arXiv, 2014
    '''

    def setUp(self):
        """Setup test environment"""
        # Create a temporary file with the sample paper
        self.temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False)
        self.temp_file.write(self.SAMPLE_PAPER)
        self.temp_file_path = self.temp_file.name
        self.temp_file.close()

    def tearDown(self):
        """Clean up test environment"""
        # Remove the temporary file
        if os.path.exists(self.temp_file_path):
            os.unlink(self.temp_file_path)

    # ========================================================================
    # CONFIGURATION TESTS
    # ========================================================================

    def test_configuration(self):
        """Test configuration management"""
        logger.info("Testing configuration management...")

        # Test getting configuration
        config = get_config()
        self.assertIsNotNone(config, "Config should not be None")

        # Test getting specific values with defaults
        gemini_key = get_config_value("GEMINI_API_KEY", "default")
        self.assertIsNotNone(gemini_key, "GEMINI_API_KEY should not be None")

        # Test default value
        test_value = get_config_value("NON_EXISTENT_VALUE", "default_value")
        self.assertEqual(test_value, "default_value", "Default value should be returned for missing keys")

        logger.info("✓ Configuration tests passed")

    # ========================================================================
    # STATE TESTS
    # ========================================================================

    def test_state_creation(self):
        """Test ReviewState dataclass creation"""
        logger.info("Testing ReviewState creation...")

        # Test creating state
        state = ReviewState(
            review_id="TEST-123",
            paper_id="paper-123"
        )

        self.assertIsNotNone(state, "State should not be None")
        self.assertEqual(state.review_id, "TEST-123", "Review ID should be set correctly")

        logger.info("✓ State creation tests passed")

    def test_state_clone(self):
        """Test ReviewState clone method"""
        logger.info("Testing ReviewState clone...")

        state = ReviewState(review_id="TEST-123", paper_id="paper-123")
        state.citation_results = [{"test": "data"}]

        # Clone state
        cloned = state.clone()

        self.assertIsNotNone(cloned, "Cloned state should not be None")
        self.assertEqual(cloned.review_id, state.review_id, "Review ID should match")
        self.assertIsNot(cloned, state, "Cloned state should be a different object")

        logger.info("✓ State clone tests passed")

    # ========================================================================
    # ANALYZER TESTS (Pure Tools)
    # ========================================================================

    def test_citation_checker(self):
        """Test CitationChecker (pure tool)"""
        logger.info("Testing CitationChecker...")

        with open(self.temp_file_path, 'r') as f:
            content = f.read()

        analyzer = CitationChecker()
        results = analyzer.check_citations(content, self.temp_file_path)

        self.assertIsNotNone(results, "Citation analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ CitationChecker tests passed")

    def test_methodology_reviewer(self):
        """Test MethodologyReviewer (pure tool)"""
        logger.info("Testing MethodologyReviewer...")

        with open(self.temp_file_path, 'r') as f:
            content = f.read()

        analyzer = MethodologyReviewer()
        results = analyzer.review_methodology(content, self.temp_file_path)

        self.assertIsNotNone(results, "Methodology review results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ MethodologyReviewer tests passed")

    def test_novelty_analyzer(self):
        """Test NoveltyAnalyzer (pure tool)"""
        logger.info("Testing NoveltyAnalyzer...")

        with open(self.temp_file_path, 'r') as f:
            content = f.read()

        analyzer = NoveltyAnalyzer()
        results = analyzer.analyze_novelty(content, self.temp_file_path)

        self.assertIsNotNone(results, "Novelty analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ NoveltyAnalyzer tests passed")

    def test_reproducibility_analyzer(self):
        """Test ReproducibilityAnalyzer (pure tool)"""
        logger.info("Testing ReproducibilityAnalyzer...")

        with open(self.temp_file_path, 'r') as f:
            content = f.read()

        analyzer = ReproducibilityAnalyzer()
        results = analyzer.analyze_reproducibility(content, self.temp_file_path)

        self.assertIsNotNone(results, "Reproducibility analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ ReproducibilityAnalyzer tests passed")

    def test_writing_quality_analyzer(self):
        """Test WritingQualityAnalyzer (pure tool)"""
        logger.info("Testing WritingQualityAnalyzer...")

        with open(self.temp_file_path, 'r') as f:
            content = f.read()

        analyzer = WritingQualityAnalyzer()
        results = analyzer.analyze_writing(content, self.temp_file_path)

        self.assertIsNotNone(results, "Writing quality analysis results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ WritingQualityAnalyzer tests passed")

    # ========================================================================
    # AGENT TESTS (Coordinators)
    # ========================================================================

    def test_base_agent(self):
        """Test BaseAgent class"""
        logger.info("Testing BaseAgent...")

        agent = BaseAgent("test_agent")

        self.assertEqual(agent.name, "test_agent", "Agent name should be set correctly")
        self.assertIsNotNone(agent.logger, "Agent should have a logger")

        # Test that analyze raises NotImplementedError
        with self.assertRaises(NotImplementedError):
            agent.analyze()

        logger.info("✓ BaseAgent tests passed")

    def test_citation_checker_agent(self):
        """Test CitationCheckerAgent (coordinator)"""
        logger.info("Testing CitationCheckerAgent...")

        with open(self.temp_file_path, 'r') as f:
            content = f.read()

        paper_data = {"content": content}

        agent = CitationCheckerAgent()
        results = agent.analyze(paper_data)

        self.assertIsNotNone(results, "Citation agent results should not be None")
        self.assertIsInstance(results, dict, "Results should be a dictionary")

        logger.info("✓ CitationCheckerAgent tests passed")

    # ========================================================================
    # NODE TESTS (Thin Wrappers)
    # ========================================================================

    def test_citation_checker_node(self):
        """Test citation_checker_node (thin wrapper)"""
        logger.info("Testing citation_checker_node...")

        with open(self.temp_file_path, 'r') as f:
            content = f.read()

        state = ReviewState(
            review_id="TEST-REVIEW",
            paper_data={"content": content}
        )

        result = citation_checker_node(state)

        self.assertIsNotNone(result, "Citation node result should not be None")
        self.assertIsInstance(result, ReviewState, "Result should be ReviewState")

        logger.info("✓ citation_checker_node tests passed")

    def test_decision_node(self):
        """Test decision_node logic"""
        logger.info("Testing decision_node...")

        # Create mock state with analysis results
        state = ReviewState(
            review_id="TEST-REVIEW",
            citation_results=[{"citation_score": 8.5}],
            methodology_results=[{"methodology_score": 8.0}],
            novelty_results=[{"novelty_score": 7.5}],
            reproducibility_results=[{"reproducibility_score": 8.5}],
            writing_quality_results=[{"writing_score": 8.0}]
        )

        result = decision_node(state)

        self.assertIsNotNone(result, "Decision result should not be None")
        self.assertIsInstance(result, ReviewState, "Result should be ReviewState")
        self.assertIsNotNone(result.decision, "Should have a decision")

        logger.info("✓ decision_node tests passed")

    # ========================================================================
    # GRAPH TESTS
    # ========================================================================

    def test_review_graph_creation(self):
        """Test ReviewGraph class creation"""
        logger.info("Testing ReviewGraph creation...")

        def dummy_node(state):
            return state

        stages = [[dummy_node]]
        graph = ReviewGraph(stages=stages, max_workers=2)

        self.assertIsNotNone(graph, "Graph should not be None")
        self.assertEqual(len(graph.stages), 1, "Should have 1 stage")
        self.assertEqual(graph.max_workers, 2, "Max workers should be 2")

        logger.info("✓ ReviewGraph creation tests passed")

    # ========================================================================
    # WORKFLOW TESTS
    # ========================================================================

    def test_workflow_builder(self):
        """Test workflow builder function"""
        logger.info("Testing workflow builder...")

        workflow = build_review_workflow(max_workers=3)

        self.assertIsNotNone(workflow, "Workflow should not be None")
        self.assertIsInstance(workflow, ReviewGraph, "Workflow should be ReviewGraph instance")
        self.assertEqual(workflow.max_workers, 3, "Max workers should be 3")
        self.assertGreater(len(workflow.stages), 0, "Should have stages")

        logger.info("✓ Workflow builder tests passed")

    # ========================================================================
    # ARCHITECTURE COMPLIANCE TESTS
    # ========================================================================

    def test_agent_analyzer_separation(self):
        """Test that agents and analyzers are properly separated"""
        logger.info("Testing agent/analyzer separation...")

        # Agents should use analyzers
        citation_agent = CitationCheckerAgent()
        self.assertIsNotNone(citation_agent.analyzer, "CitationCheckerAgent should have an analyzer")
        self.assertIsInstance(citation_agent.analyzer, CitationChecker, "Should use CitationChecker")

        logger.info("✓ Agent/Analyzer separation tests passed")

    def test_node_purity(self):
        """Test that nodes are pure wrappers (no orchestration)"""
        logger.info("Testing node purity...")

        with open(self.temp_file_path, 'r') as f:
            content = f.read()

        state = ReviewState(
            review_id="TEST-REVIEW",
            paper_data={"content": content}
        )

        # Test that nodes return ReviewState
        result = citation_checker_node(state)
        self.assertIsInstance(result, ReviewState, "Node should return ReviewState")

        logger.info("✓ Node purity tests passed")


def run_tests():
    """Run all tests"""
    logger.info("=" * 70)
    logger.info("Academic Paper Reviewer Pipeline - Test Suite")
    logger.info("=" * 70)

    # Run tests
    unittest.main(argv=['first-arg-is-ignored'], exit=False, verbosity=2)


if __name__ == "__main__":
    run_tests()
