cp /home/coder/project/workspace/pytest/tests.py /home/coder/project/workspace/Project/tests.py
cd /home/coder/project/workspace/Project
pip install pytest
python3 -m pytest tests.py -v
