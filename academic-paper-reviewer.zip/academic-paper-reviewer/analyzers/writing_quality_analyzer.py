"""
Writing Quality Analyzer

Pure tool for assessing writing quality and clarity.
No state management - just assessment logic.
"""

from typing import Dict, Any, List
import logging

logger = logging.getLogger("analyzer.writing_quality")


class WritingQualityAnalyzer:
    """Analyzer for writing quality assessment"""

    def assess_writing_quality(self, paper_content: str, paper_abstract: str) -> Dict[str, Any]:
        """
        Assess writing quality and clarity

        Args:
            paper_content: Full paper content
            paper_abstract: Paper abstract

        Returns:
            Dictionary containing writing quality assessment
        """
        logger.info("Assessing writing quality")

        # Basic metrics
        word_count = len(paper_content.split())
        sentence_count = paper_content.count('.') + paper_content.count('!') + paper_content.count('?')
        avg_sentence_length = word_count / max(sentence_count, 1)

        # Check for standard sections
        content_lower = paper_content.lower()
        standard_sections = ["abstract", "introduction", "methodology", "results", "discussion", "conclusion"]
        sections_present = sum(1 for section in standard_sections if section in content_lower)

        # Check for clarity indicators
        clarity_keywords = ["clearly", "specifically", "precisely", "explicitly", "namely"]
        clarity_count = sum(1 for kw in clarity_keywords if kw in content_lower)

        # Check for organization quality
        organization_indicators = ["first", "second", "finally", "furthermore", "moreover", "however"]
        organization_count = sum(1 for indicator in organization_indicators if indicator in content_lower)

        # Grammar issues (simple heuristic - would use NLP in production)
        grammar_issues = []
        if avg_sentence_length > 30:
            grammar_issues.append("Some sentences may be too long")
        if avg_sentence_length < 10:
            grammar_issues.append("Some sentences may be too short")

        # Passive voice check (simplified)
        passive_indicators = ["was", "were", "been", "being"]
        passive_count = sum(1 for indicator in passive_indicators if content_lower.count(indicator) > 10)
        if passive_count > 2:
            grammar_issues.append("Frequent use of passive voice")

        # Calculate readability score (simplified Flesch reading ease)
        # Higher is easier to read
        readability_score = 100 - (avg_sentence_length * 0.5)
        readability_score = max(0, min(readability_score, 100))

        # Calculate writing quality score
        writing_quality_score = 5.0  # Base score

        # Points for structure
        writing_quality_score += min(sections_present * 0.5, 2.5)

        # Points for clarity
        writing_quality_score += min(clarity_count * 0.1, 1.0)

        # Points for organization
        writing_quality_score += min(organization_count * 0.1, 1.0)

        # Deduct for grammar issues
        writing_quality_score -= len(grammar_issues) * 0.3

        # Points for readability
        if readability_score >= 60:
            writing_quality_score += 0.5

        writing_quality_score = max(0, min(writing_quality_score, 10.0))

        # Determine clarity rating
        if writing_quality_score >= 8.0:
            clarity_rating = "Excellent"
        elif writing_quality_score >= 7.0:
            clarity_rating = "Good"
        elif writing_quality_score >= 5.0:
            clarity_rating = "Adequate"
        else:
            clarity_rating = "Needs Improvement"

        # Organization quality
        if sections_present >= 5:
            organization_quality = "Well-organized"
        elif sections_present >= 3:
            organization_quality = "Adequately organized"
        else:
            organization_quality = "Needs better organization"

        # Writing strengths
        writing_strengths = []
        if sections_present >= 5:
            writing_strengths.append("Well-structured with clear sections")
        if clarity_count >= 3:
            writing_strengths.append("Good use of clarity indicators")
        if readability_score >= 70:
            writing_strengths.append("Good readability")

        # Writing weaknesses
        writing_weaknesses = []
        if sections_present < 4:
            writing_weaknesses.append("Missing some standard sections")
        if grammar_issues:
            writing_weaknesses.extend(grammar_issues)
        if readability_score < 50:
            writing_weaknesses.append("Readability could be improved")

        # Recommendations
        recommendations = []
        if writing_quality_score < 7.0:
            recommendations.append("Improve overall writing quality and clarity")
        if sections_present < 5:
            recommendations.append("Include all standard sections")
        if len(grammar_issues) > 0:
            recommendations.append("Review and address grammar issues")
        if readability_score < 60:
            recommendations.append("Simplify sentence structure for better readability")

        result = {
            "writing_quality_score": round(writing_quality_score, 2),
            "clarity_rating": clarity_rating,
            "organization_quality": organization_quality,
            "grammar_issues": grammar_issues,
            "readability_score": round(readability_score, 2),
            "writing_strengths": writing_strengths,
            "writing_weaknesses": writing_weaknesses,
            "recommendations": recommendations
        }

        logger.info(f"Writing quality assessment complete: Score {writing_quality_score:.1f}/10")
        return result
