"""
Methodology Reviewer

Pure tool for reviewing research methodology and experimental design.
No state management - just review logic.
"""

from typing import Dict, Any, List
import logging

logger = logging.getLogger("analyzer.methodology_reviewer")


class MethodologyReviewer:
    """Analyzer for methodology and experimental design review"""

    def review_methodology(self, paper_content: str, paper_metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        Review research methodology and experimental design

        Args:
            paper_content: Full paper content
            paper_metadata: Paper metadata

        Returns:
            Dictionary containing methodology review
        """
        logger.info("Reviewing research methodology")

        # Check for methodology section
        content_lower = paper_content.lower()
        has_methodology_section = "methodology" in content_lower or "methods" in content_lower

        # Check for experimental design keywords
        experimental_keywords = ["experiment", "study", "sample", "participants", "data collection", "procedure"]
        experimental_rigor = sum(1 for kw in experimental_keywords if kw in content_lower)

        # Check for statistical analysis
        statistical_keywords = ["statistical", "significance", "p-value", "confidence interval", "hypothesis"]
        has_statistics = any(kw in content_lower for kw in statistical_keywords)

        # Assess research design quality
        design_indicators = ["control group", "randomization", "blinding", "baseline", "validation"]
        design_quality_count = sum(1 for indicator in design_indicators if indicator in content_lower)

        # Calculate methodology score
        methodology_score = 5.0  # Base score

        if has_methodology_section:
            methodology_score += 2.0

        methodology_score += min(experimental_rigor * 0.3, 2.0)

        if has_statistics:
            methodology_score += 0.5

        methodology_score += min(design_quality_count * 0.2, 1.0)

        methodology_score = min(methodology_score, 10.0)

        # Determine research design quality
        if methodology_score >= 8.0:
            research_design_quality = "Excellent"
        elif methodology_score >= 7.0:
            research_design_quality = "Good"
        elif methodology_score >= 5.0:
            research_design_quality = "Adequate"
        else:
            research_design_quality = "Needs Improvement"

        # Assess experimental rigor
        if experimental_rigor >= 4:
            experimental_rigor_level = "High"
        elif experimental_rigor >= 2:
            experimental_rigor_level = "Moderate"
        else:
            experimental_rigor_level = "Low"

        # Statistical validity
        statistical_validity = "Present" if has_statistics else "Not evident"

        # Identify issues
        methodology_issues = []
        if not has_methodology_section:
            methodology_issues.append("No clear methodology section found")
        if experimental_rigor < 2:
            methodology_issues.append("Insufficient experimental design details")
        if not has_statistics:
            methodology_issues.append("No statistical analysis mentioned")

        # Identify strengths
        methodology_strengths = []
        if has_methodology_section:
            methodology_strengths.append("Clear methodology section present")
        if design_quality_count >= 3:
            methodology_strengths.append("Rigorous experimental design")
        if has_statistics:
            methodology_strengths.append("Statistical analysis included")

        # Recommendations
        recommendations = []
        if methodology_score < 7.0:
            recommendations.append("Strengthen methodology description with more details")
        if not has_statistics:
            recommendations.append("Add statistical validation of results")
        if experimental_rigor < 3:
            recommendations.append("Provide more experimental setup details")

        result = {
            "methodology_score": round(methodology_score, 2),
            "research_design_quality": research_design_quality,
            "experimental_rigor": experimental_rigor_level,
            "statistical_validity": statistical_validity,
            "methodology_issues": methodology_issues,
            "methodology_strengths": methodology_strengths,
            "recommendations": recommendations
        }

        logger.info(f"Methodology review complete: Score {methodology_score:.1f}/10")
        return result
