"""
Novelty Analyzer

Pure tool for analyzing research novelty and contributions.
No state management - just analysis logic.
"""

from typing import Dict, Any, List
import logging

logger = logging.getLogger("analyzer.novelty_analyzer")


class NoveltyAnalyzer:
    """Analyzer for novelty and contribution assessment"""

    def analyze_novelty(self, paper_content: str, paper_abstract: str, paper_metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze research novelty and contributions

        Args:
            paper_content: Full paper content
            paper_abstract: Paper abstract
            paper_metadata: Paper metadata

        Returns:
            Dictionary containing novelty analysis
        """
        logger.info("Analyzing research novelty")

        content_lower = paper_content.lower()
        abstract_lower = paper_abstract.lower()

        # Check for novelty claims
        novelty_keywords = ["novel", "new", "innovative", "first time", "unprecedented", "original"]
        novelty_claims = sum(1 for kw in novelty_keywords if kw in abstract_lower or kw in content_lower[:1000])

        # Check for contribution statements
        contribution_keywords = ["contribution", "propose", "introduce", "present a new", "demonstrate"]
        contribution_count = sum(1 for kw in contribution_keywords if kw in abstract_lower)

        # Check for comparison with existing work
        comparison_keywords = ["compared to", "unlike previous", "different from", "improves upon", "extends"]
        has_comparison = any(kw in content_lower for kw in comparison_keywords)

        # Check for innovation indicators
        innovation_keywords = ["breakthrough", "paradigm", "groundbreaking", "state-of-the-art", "cutting-edge"]
        innovation_count = sum(1 for kw in innovation_keywords if kw in content_lower)

        # Calculate novelty score
        novelty_score = 4.0  # Base score

        novelty_score += min(novelty_claims * 0.5, 2.0)
        novelty_score += min(contribution_count * 0.4, 1.5)

        if has_comparison:
            novelty_score += 1.0

        novelty_score += min(innovation_count * 0.3, 1.5)

        novelty_score = min(novelty_score, 10.0)

        # Determine contribution level
        if novelty_score >= 8.5:
            contribution_level = "Major Contribution"
        elif novelty_score >= 7.0:
            contribution_level = "Significant Contribution"
        elif novelty_score >= 5.5:
            contribution_level = "Moderate Contribution"
        else:
            contribution_level = "Minor Contribution"

        # Extract key contributions (mock - would use NLP in production)
        key_contributions = []
        if "contribution" in abstract_lower:
            key_contributions.append("Stated contributions in abstract")
        if novelty_claims > 0:
            key_contributions.append("Claims of novel approach or method")
        if innovation_count > 0:
            key_contributions.append("Innovative techniques or results")

        # Existing work comparison
        if has_comparison:
            existing_work_comparison = "Adequately compared with existing approaches"
        else:
            existing_work_comparison = "Limited comparison with existing work"

        # Innovation assessment
        if innovation_count >= 2:
            innovation_assessment = "High level of innovation"
        elif innovation_count >= 1:
            innovation_assessment = "Moderate innovation"
        else:
            innovation_assessment = "Incremental improvement"

        # Identify concerns
        novelty_concerns = []
        if novelty_claims == 0:
            novelty_concerns.append("No explicit novelty claims in abstract")
        if not has_comparison:
            novelty_concerns.append("Insufficient comparison with prior work")
        if contribution_count == 0:
            novelty_concerns.append("Contributions not clearly stated")

        # Recommendations
        recommendations = []
        if novelty_score < 6.0:
            recommendations.append("Strengthen novelty claims and clarify contributions")
        if not has_comparison:
            recommendations.append("Add detailed comparison with existing approaches")
        if contribution_count == 0:
            recommendations.append("Explicitly state key contributions in abstract")

        result = {
            "novelty_score": round(novelty_score, 2),
            "contribution_level": contribution_level,
            "key_contributions": key_contributions,
            "existing_work_comparison": existing_work_comparison,
            "innovation_assessment": innovation_assessment,
            "novelty_concerns": novelty_concerns,
            "recommendations": recommendations
        }

        logger.info(f"Novelty analysis complete: Score {novelty_score:.1f}/10")
        return result
