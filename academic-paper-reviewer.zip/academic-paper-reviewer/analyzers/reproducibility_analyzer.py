"""
Reproducibility Analyzer

Pure tool for assessing research reproducibility.
No state management - just assessment logic.
"""

from typing import Dict, Any, List
import logging

logger = logging.getLogger("analyzer.reproducibility")


class ReproducibilityAnalyzer:
    """Analyzer for reproducibility assessment"""

    def assess_reproducibility(self, paper_content: str, paper_metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        Assess research reproducibility

        Args:
            paper_content: Full paper content
            paper_metadata: Paper metadata

        Returns:
            Dictionary containing reproducibility assessment
        """
        logger.info("Assessing research reproducibility")

        content_lower = paper_content.lower()

        # Check for code availability
        code_keywords = ["code available", "github", "repository", "source code", "implementation"]
        code_availability = any(kw in content_lower for kw in code_keywords)

        # Check for data availability
        data_keywords = ["data available", "dataset", "supplementary data", "data repository"]
        data_availability = any(kw in content_lower for kw in data_keywords)

        # Check for implementation details
        implementation_keywords = ["hyperparameter", "parameter settings", "configuration", "implementation detail"]
        implementation_detail_count = sum(1 for kw in implementation_keywords if kw in content_lower)

        # Check for experimental setup clarity
        setup_keywords = ["setup", "environment", "hardware", "software", "framework", "library"]
        setup_detail_count = sum(1 for kw in setup_keywords if kw in content_lower)

        # Calculate reproducibility score
        reproducibility_score = 3.0  # Base score

        if code_availability:
            reproducibility_score += 3.0

        if data_availability:
            reproducibility_score += 2.0

        reproducibility_score += min(implementation_detail_count * 0.4, 1.5)
        reproducibility_score += min(setup_detail_count * 0.2, 1.0)

        reproducibility_score = min(reproducibility_score, 10.0)

        # Implementation details assessment
        if implementation_detail_count >= 3:
            implementation_details = "Comprehensive implementation details"
        elif implementation_detail_count >= 1:
            implementation_details = "Some implementation details provided"
        else:
            implementation_details = "Limited implementation details"

        # Experimental setup clarity
        if setup_detail_count >= 4:
            experimental_setup_clarity = "Very clear"
        elif setup_detail_count >= 2:
            experimental_setup_clarity = "Moderately clear"
        else:
            experimental_setup_clarity = "Unclear"

        # Reproducibility issues
        reproducibility_issues = []
        if not code_availability:
            reproducibility_issues.append("Code not made available")
        if not data_availability:
            reproducibility_issues.append("Data not made available")
        if implementation_detail_count < 2:
            reproducibility_issues.append("Insufficient implementation details")
        if setup_detail_count < 2:
            reproducibility_issues.append("Experimental setup not clearly described")

        # Reproducibility strengths
        reproducibility_strengths = []
        if code_availability:
            reproducibility_strengths.append("Code made available")
        if data_availability:
            reproducibility_strengths.append("Data made available")
        if implementation_detail_count >= 3:
            reproducibility_strengths.append("Detailed implementation description")
        if setup_detail_count >= 4:
            reproducibility_strengths.append("Clear experimental setup")

        # Recommendations
        recommendations = []
        if not code_availability:
            recommendations.append("Make source code publicly available")
        if not data_availability:
            recommendations.append("Share datasets or provide access instructions")
        if implementation_detail_count < 3:
            recommendations.append("Provide more implementation details (hyperparameters, settings)")
        if setup_detail_count < 3:
            recommendations.append("Describe experimental environment more clearly")
        if reproducibility_score >= 8.0:
            recommendations.append("Excellent reproducibility - strong open science practices")

        result = {
            "reproducibility_score": round(reproducibility_score, 2),
            "code_availability": code_availability,
            "data_availability": data_availability,
            "implementation_details": implementation_details,
            "experimental_setup_clarity": experimental_setup_clarity,
            "reproducibility_issues": reproducibility_issues,
            "reproducibility_strengths": reproducibility_strengths,
            "recommendations": recommendations
        }

        logger.info(f"Reproducibility assessment complete: Score {reproducibility_score:.1f}/10")
        return result
