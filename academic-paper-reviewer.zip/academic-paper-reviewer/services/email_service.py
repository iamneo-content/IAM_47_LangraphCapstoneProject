"""
Email Notification Service

Sends email notifications for paper review events.
"""

import smtplib
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional
from config import get_config_value

logger = logging.getLogger("service.email")


class EmailService:
    """Service for sending email notifications"""

    def __init__(self):
        """Initialize email service"""
        self.smtp_server = get_config_value("SMTP_SERVER", "smtp.gmail.com")
        self.smtp_port = get_config_value("SMTP_PORT", 587)
        self.email_from = get_config_value("EMAIL_FROM", "")
        self.email_password = get_config_value("EMAIL_PASSWORD", "")
        self.email_to = get_config_value("EMAIL_TO", "")

    def send_email(self, subject: str, body: str, html: bool = False) -> bool:
        """
        Send an email

        Args:
            subject: Email subject
            body: Email body
            html: Whether body is HTML (default: False)

        Returns:
            True if sent successfully, False otherwise
        """
        if not all([self.email_from, self.email_password, self.email_to]):
            logger.warning("Email configuration incomplete, skipping email")
            return False

        try:
            # Create message
            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["From"] = self.email_from
            msg["To"] = self.email_to

            # Add body
            if html:
                msg.attach(MIMEText(body, "html"))
            else:
                msg.attach(MIMEText(body, "plain"))

            # Send email
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.email_from, self.email_password)
                server.send_message(msg)

            logger.info(f"Email sent successfully: {subject}")
            return True

        except Exception as e:
            logger.error(f"Failed to send email: {e}")
            return False

    def send_review_start_email(self, review_id: str, paper_title: str, venue: str) -> bool:
        """
        Send notification that review has started

        Args:
            review_id: Review ID
            paper_title: Paper title
            venue: Conference/journal name

        Returns:
            True if sent successfully
        """
        subject = f"Paper Review Started - {paper_title}"

        body = f"""
Academic Paper Review Started

Review ID: {review_id}
Paper: {paper_title}
Venue: {venue}

Automated peer review is now in progress. You will receive a final report once complete.

This is an automated message from the Academic Paper Reviewer system.
        """

        return self.send_email(subject, body.strip())

    def send_final_report_email(self, state) -> bool:
        """
        Send final review report

        Args:
            state: PaperReviewState with complete review results

        Returns:
            True if sent successfully
        """
        subject = f"Review Complete - {state.paper_title} - {state.decision}"

        # Build email body
        body = f"""
ACADEMIC PAPER REVIEW COMPLETE
{'='*60}

Review ID: {state.review_id}
Paper: {state.paper_title}
Authors: {', '.join(state.authors)}
Venue: {state.conference_journal}
Timestamp: {state.timestamp}

DECISION: {state.decision}
OVERALL SCORE: {state.overall_score:.2f}/10.0
CONFIDENCE: {state.confidence_level}

{'='*60}
REVIEW METRICS
{'='*60}

Methodology Score:    {state.decision_metrics.get('methodology_score', 0):.2f}/10.0
Novelty Score:        {state.decision_metrics.get('novelty_score', 0):.2f}/10.0
Citation Score:       {state.decision_metrics.get('citation_score', 0):.2f}/10.0
Writing Quality:      {state.decision_metrics.get('writing_quality_score', 0):.2f}/10.0
Reproducibility:      {state.decision_metrics.get('reproducibility_score', 0):.2f}/10.0

{'='*60}
STRENGTHS
{'='*60}

"""
        if state.strengths:
            for strength in state.strengths[:5]:
                body += f"  + {strength}\n"

        body += f"\n{'='*60}\n"
        body += "WEAKNESSES\n"
        body += f"{'='*60}\n\n"

        if state.weaknesses:
            for weakness in state.weaknesses[:5]:
                body += f"  - {weakness}\n"

        if state.has_critical_issues:
            body += f"\n[!] CRITICAL ISSUES: {state.critical_reason}\n"

        body += f"\n{'='*60}\n"
        body += "REVIEWER COMMENTS\n"
        body += f"{'='*60}\n\n"

        if state.reviewer_comments:
            for comment in state.reviewer_comments:
                body += f"  • {comment}\n"

        if state.decision in ["MAJOR_REVISION", "MINOR_REVISION"] and state.revision_suggestions:
            body += f"\n{'='*60}\n"
            body += "REVISION SUGGESTIONS\n"
            body += f"{'='*60}\n\n"
            for i, suggestion in enumerate(state.revision_suggestions, 1):
                body += f"  {i}. {suggestion}\n"

        body += "\n" + "="*60 + "\n"
        body += "This is an automated message from the Academic Paper Reviewer system.\n"

        return self.send_email(subject, body.strip())
