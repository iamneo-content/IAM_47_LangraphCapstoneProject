"""
Coordinator Node - Simplified Wrapper

Calls CoordinatorAgent to coordinate and aggregate results.
"""

from state import PaperReviewState
from agents.coordinator_agent import CoordinatorAgent

# Create agent instance
agent = CoordinatorAgent()


def coordinator_node(state: PaperReviewState) -> PaperReviewState:
    """
    Coordinate and aggregate review results

    Args:
        state: Current paper review state

    Returns:
        Updated state with coordination summary
    """
    state.coordination_summary = agent.analyze(
        state.methodology_results,
        state.novelty_results,
        state.citation_results,
        state.writing_quality_results,
        state.reproducibility_results
    )

    # Also extract strengths and weaknesses
    state.strengths = state.coordination_summary.get("strengths", [])
    state.weaknesses = state.coordination_summary.get("weaknesses", [])

    return state
