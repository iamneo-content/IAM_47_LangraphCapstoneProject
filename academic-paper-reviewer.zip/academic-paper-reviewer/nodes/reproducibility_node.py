"""
Reproducibility Node - Simplified Wrapper

Calls ReproducibilityAgent to assess reproducibility.
"""

from state import PaperReviewState
from agents.reproducibility_agent import ReproducibilityAgent

# Create agent instance
agent = ReproducibilityAgent()


def reproducibility_node(state: PaperReviewState) -> PaperReviewState:
    """
    Assess research reproducibility

    Args:
        state: Current paper review state

    Returns:
        Updated state with reproducibility results
    """
    state.reproducibility_results = agent.analyze(state.paper_content, state.paper_metadata)
    return state
