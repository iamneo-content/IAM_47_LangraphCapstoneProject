"""
Writing Quality Node - Simplified Wrapper

Calls WritingQualityAgent to assess writing quality.
"""

from state import PaperReviewState
from agents.writing_quality_agent import WritingQualityAgent

# Create agent instance
agent = WritingQualityAgent()


def writing_quality_node(state: PaperReviewState) -> PaperReviewState:
    """
    Assess writing quality

    Args:
        state: Current paper review state

    Returns:
        Updated state with writing quality results
    """
    state.writing_quality_results = agent.analyze(state.paper_content, state.paper_abstract)
    return state
