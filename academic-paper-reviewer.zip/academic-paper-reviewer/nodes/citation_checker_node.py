"""
Citation Checker Node - Simplified Wrapper

Calls CitationCheckerAgent to check citations.
"""

from state import PaperReviewState
from agents.citation_checker_agent import CitationCheckerAgent

# Create agent instance
agent = CitationCheckerAgent()


def citation_checker_node(state: PaperReviewState) -> PaperReviewState:
    """
    Check citations and references

    Args:
        state: Current paper review state

    Returns:
        Updated state with citation check results
    """
    state.citation_results = agent.analyze(state.paper_content, state.paper_metadata)
    return state
