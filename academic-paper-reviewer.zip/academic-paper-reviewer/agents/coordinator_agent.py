"""
Coordinator Agent

Agent responsible for coordinating and aggregating results from all review agents.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent


class CoordinatorAgent(BaseAgent):
    """Agent for coordinating and aggregating review results"""

    def __init__(self):
        """Initialize coordinator agent"""
        super().__init__("coordinator")
        self.log("Coordinator agent initialized")

    def analyze(self, methodology_results: List[Dict[str, Any]],
                novelty_results: List[Dict[str, Any]],
                citation_results: List[Dict[str, Any]],
                writing_quality_results: List[Dict[str, Any]],
                reproducibility_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Coordinate and aggregate results from all review agents

        Args:
            methodology_results: Results from methodology reviewer agent
            novelty_results: Results from novelty analyzer agent
            citation_results: Results from citation checker agent
            writing_quality_results: Results from writing quality agent
            reproducibility_results: Results from reproducibility agent

        Returns:
            Coordinated summary of all results
        """
        self.log("Coordinating results from all review agents")

        # Extract scores
        methodology_score = methodology_results[0].get("methodology_score", 0) if methodology_results else 0
        novelty_score = novelty_results[0].get("novelty_score", 0) if novelty_results else 0
        citation_score = citation_results[0].get("citation_score", 0) if citation_results else 0
        writing_score = writing_quality_results[0].get("writing_quality_score", 0) if writing_quality_results else 0
        reproducibility_score = reproducibility_results[0].get("reproducibility_score", 0) if reproducibility_results else 0

        # Calculate overall score (weighted average)
        # Methodology: 30%, Novelty: 25%, Citations: 15%, Writing: 15%, Reproducibility: 15%
        overall_score = (
            methodology_score * 0.30 +
            novelty_score * 0.25 +
            citation_score * 0.15 +
            writing_score * 0.15 +
            reproducibility_score * 0.15
        )

        # Check for critical issues
        has_critical_issues = False
        critical_issues = []

        if methodology_score < 5.0:
            critical_issues.append("Methodology score critically low")
        if novelty_score < 4.0:
            critical_issues.append("Insufficient novelty/contribution")
        if reproducibility_score < 5.0:
            critical_issues.append("Reproducibility concerns")
        if citation_results and len(citation_results[0].get("missing_citations", [])) > 5:
            critical_issues.append("Missing important citations")

        # Collect strengths
        strengths = []
        if methodology_results:
            strengths.extend(methodology_results[0].get("methodology_strengths", []))
        if writing_quality_results:
            strengths.extend(writing_quality_results[0].get("writing_strengths", []))
        if reproducibility_results:
            strengths.extend(reproducibility_results[0].get("reproducibility_strengths", []))

        # Collect weaknesses
        weaknesses = []
        if methodology_results:
            weaknesses.extend(methodology_results[0].get("methodology_issues", []))
        if novelty_results:
            weaknesses.extend(novelty_results[0].get("novelty_concerns", []))
        if citation_results:
            weaknesses.extend(citation_results[0].get("citation_issues", []))
        if writing_quality_results:
            weaknesses.extend(writing_quality_results[0].get("writing_weaknesses", []))
        if reproducibility_results:
            weaknesses.extend(reproducibility_results[0].get("reproducibility_issues", []))

        coordination_summary = {
            "overall_score": round(overall_score, 2),
            "methodology_score": round(methodology_score, 2),
            "novelty_score": round(novelty_score, 2),
            "citation_score": round(citation_score, 2),
            "writing_quality_score": round(writing_score, 2),
            "reproducibility_score": round(reproducibility_score, 2),
            "total_agents": 5,
            "has_critical_issues": len(critical_issues) > 0,
            "critical_issues": critical_issues,
            "strengths": strengths[:10],  # Top 10 strengths
            "weaknesses": weaknesses[:10],  # Top 10 weaknesses
            "analysis_complete": True
        }

        self.log(f"Coordination complete: Overall score {overall_score:.2f}/10")
        return coordination_summary
