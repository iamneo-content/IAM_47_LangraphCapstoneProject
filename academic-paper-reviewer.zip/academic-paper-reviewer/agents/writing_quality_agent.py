"""
Writing Quality Agent

Agent responsible for assessing writing quality and clarity.
Uses WritingQualityAnalyzer as a tool for actual assessment.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent
from analyzers.writing_quality_analyzer import WritingQualityAnalyzer


class WritingQualityAgent(BaseAgent):
    """Agent for writing quality assessment"""

    def __init__(self):
        """Initialize writing quality agent with analyzer"""
        super().__init__("writing_quality")
        self.analyzer = WritingQualityAnalyzer()
        self.log("Writing quality agent initialized")

    def analyze(self, paper_content: str, paper_abstract: str) -> List[Dict[str, Any]]:
        """
        Assess writing quality and clarity

        Pure reasoning logic only - coordinates assessment using analyzer tool

        Args:
            paper_content: Full paper content
            paper_abstract: Paper abstract

        Returns:
            List of writing quality assessment results
        """
        self.log("Assessing writing quality and clarity")
        results: List[Dict[str, Any]] = []

        # Use analyzer tool for actual assessment
        assessment = self.analyzer.assess_writing_quality(paper_content, paper_abstract)

        results.append({
            "writing_quality_score": assessment.get("writing_quality_score", 0),
            "clarity_rating": assessment.get("clarity_rating", ""),
            "organization_quality": assessment.get("organization_quality", ""),
            "grammar_issues": assessment.get("grammar_issues", []),
            "readability_score": assessment.get("readability_score", 0),
            "writing_strengths": assessment.get("writing_strengths", []),
            "writing_weaknesses": assessment.get("writing_weaknesses", []),
            "recommendations": assessment.get("recommendations", [])
        })

        score = assessment.get("writing_quality_score", 0)
        self.log(f"Writing quality assessment complete: Score {score}/10")
        return results
