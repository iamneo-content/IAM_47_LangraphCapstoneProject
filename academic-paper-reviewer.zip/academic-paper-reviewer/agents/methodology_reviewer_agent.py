"""
Methodology Reviewer Agent

Agent responsible for reviewing research methodology and experimental design.
Uses MethodologyReviewer as a tool for actual review.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent
from analyzers.methodology_reviewer import MethodologyReviewer


class MethodologyReviewerAgent(BaseAgent):
    """Agent for methodology and experimental design review"""

    def __init__(self):
        """Initialize methodology reviewer agent with reviewer"""
        super().__init__("methodology_reviewer")
        self.reviewer = MethodologyReviewer()
        self.log("Methodology reviewer agent initialized")

    def analyze(self, paper_content: str, paper_metadata: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Review research methodology and experimental design

        Pure reasoning logic only - coordinates review using reviewer tool

        Args:
            paper_content: Full paper content
            paper_metadata: Paper metadata including field, type, etc.

        Returns:
            List of methodology review results
        """
        self.log("Reviewing research methodology")
        results: List[Dict[str, Any]] = []

        # Use reviewer tool for actual review
        review = self.reviewer.review_methodology(paper_content, paper_metadata)

        results.append({
            "methodology_score": review.get("methodology_score", 0),
            "research_design_quality": review.get("research_design_quality", ""),
            "experimental_rigor": review.get("experimental_rigor", ""),
            "statistical_validity": review.get("statistical_validity", ""),
            "methodology_issues": review.get("methodology_issues", []),
            "methodology_strengths": review.get("methodology_strengths", []),
            "recommendations": review.get("recommendations", [])
        })

        score = review.get("methodology_score", 0)
        issues = len(review.get("methodology_issues", []))
        self.log(f"Methodology review complete: Score {score}/10, {issues} issues found")
        return results
