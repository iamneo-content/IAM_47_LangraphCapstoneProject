"""
Reproducibility Agent

Agent responsible for assessing research reproducibility.
Uses ReproducibilityAnalyzer as a tool for actual assessment.
"""

from typing import List, Dict, Any
from .base_agent import BaseAgent
from analyzers.reproducibility_analyzer import ReproducibilityAnalyzer


class ReproducibilityAgent(BaseAgent):
    """Agent for reproducibility assessment"""

    def __init__(self):
        """Initialize reproducibility agent with analyzer"""
        super().__init__("reproducibility")
        self.analyzer = ReproducibilityAnalyzer()
        self.log("Reproducibility agent initialized")

    def analyze(self, paper_content: str, paper_metadata: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Assess research reproducibility

        Pure reasoning logic only - coordinates assessment using analyzer tool

        Args:
            paper_content: Full paper content
            paper_metadata: Paper metadata

        Returns:
            List of reproducibility assessment results
        """
        self.log("Assessing research reproducibility")
        results: List[Dict[str, Any]] = []

        # Use analyzer tool for actual assessment
        assessment = self.analyzer.assess_reproducibility(paper_content, paper_metadata)

        results.append({
            "reproducibility_score": assessment.get("reproducibility_score", 0),
            "code_availability": assessment.get("code_availability", False),
            "data_availability": assessment.get("data_availability", False),
            "implementation_details": assessment.get("implementation_details", ""),
            "experimental_setup_clarity": assessment.get("experimental_setup_clarity", ""),
            "reproducibility_issues": assessment.get("reproducibility_issues", []),
            "reproducibility_strengths": assessment.get("reproducibility_strengths", []),
            "recommendations": assessment.get("recommendations", [])
        })

        score = assessment.get("reproducibility_score", 0)
        code_avail = assessment.get("code_availability", False)
        self.log(f"Reproducibility assessment complete: Score {score}/10, Code available: {code_avail}")
        return results
