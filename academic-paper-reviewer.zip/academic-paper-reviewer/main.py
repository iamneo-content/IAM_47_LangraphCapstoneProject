"""
Academic Paper Reviewer - Client Format
Main application entry point
"""

import sys
import argparse
from datetime import datetime
import uuid

from config import validate_config, get_config_value
from state import PaperReviewState
from workflows.review_workflow import build_review_workflow
from utils.logging_utils import setup_logging


def main():
    """Main application entry point"""
    # Setup logging
    log_file = get_config_value("LOG_FILE", "logs/paper_review.log")
    log_level = get_config_value("LOG_LEVEL", "INFO")
    setup_logging(log_level, log_file)

    # Parse arguments
    parser = argparse.ArgumentParser(
        description="Academic Paper Reviewer - Multi-Agent Peer Review System"
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Review paper command
    review_parser = subparsers.add_parser("review", help="Review an academic paper")
    review_parser.add_argument("paper_title", help="Paper title")
    review_parser.add_argument("--paper-file", help="Path to paper file")
    review_parser.add_argument("--conference", default="Conference", help="Conference/Journal name")
    review_parser.add_argument("--max-workers", type=int, default=5, help="Maximum parallel workers")

    # Demo command
    demo_parser = subparsers.add_parser("demo", help="Run demo with sample paper")
    demo_parser.add_argument("--max-workers", type=int, default=5, help="Maximum parallel workers")

    args = parser.parse_args()

    try:
        # Validate configuration
        validate_config()

        # Handle commands
        if args.command == "review":
            paper_content = ""
            if args.paper_file:
                with open(args.paper_file, 'r') as f:
                    paper_content = f.read()
            else:
                paper_content = get_sample_paper()

            review_paper(args.paper_title, paper_content, args.conference, args.max_workers)
        elif args.command == "demo":
            run_demo(args.max_workers)
        else:
            # Interactive mode
            interactive_mode()

    except Exception as e:
        print(f"ERROR: {e}")
        sys.exit(1)


def review_paper(paper_title: str, paper_content: str, conference: str, max_workers: int = 5):
    """
    Review an academic paper

    Args:
        paper_title: Paper title
        paper_content: Full paper content
        conference: Conference/journal name
        max_workers: Maximum parallel workers
    """
    print(f"\n{'='*70}")
    print(f"ACADEMIC PAPER REVIEWER - CLIENT FORMAT")
    print(f"{'='*70}")
    print(f"Paper: {paper_title}")
    print(f"Venue: {conference}")
    print(f"Max Workers: {max_workers}")
    print(f"{'='*70}\n")

    # Create initial state
    review_id = f"REV-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:8].upper()}"
    paper_id = f"PAPER-{str(uuid.uuid4())[:8].upper()}"

    # Extract abstract (first paragraph after title)
    abstract = extract_abstract(paper_content)

    # Sample metadata
    paper_metadata = {
        "field": "Computer Science",
        "paper_type": "Research",
        "submission_date": datetime.now().strftime("%Y-%m-%d")
    }

    initial_state = PaperReviewState(
        review_id=review_id,
        paper_title=paper_title,
        paper_id=paper_id,
        authors=["Author A.", "Author B.", "Author C."],
        conference_journal=conference,
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        paper_abstract=abstract,
        paper_content=paper_content,
        paper_metadata=paper_metadata
    )

    print(f"Review ID: {review_id}")
    print(f"Starting workflow execution...\n")

    # Build and execute workflow
    workflow = build_review_workflow(max_workers=max_workers)
    final_state = workflow.run(initial_state)

    # Display results
    display_results(final_state)


def display_results(state: PaperReviewState):
    """Display workflow results"""
    print(f"\n{'='*70}")
    print("REVIEW COMPLETE")
    print(f"{'='*70}")
    print(f"Review ID: {state.review_id}")
    print(f"Paper: {state.paper_title}")
    print(f"Overall Score: {state.overall_score:.2f}/10.0")
    print(f"Decision: {state.decision}")
    print(f"Confidence: {state.confidence_level}")

    if state.has_critical_issues:
        print(f"\n[!] CRITICAL ISSUES: {state.critical_reason}")
    else:
        print(f"\n[OK] No critical issues found")

    # Display metrics
    if state.decision_metrics:
        print(f"\n{'='*70}")
        print("REVIEW METRICS")
        print(f"{'='*70}")
        metrics = state.decision_metrics
        print(f"Methodology Score:      {metrics.get('methodology_score', 0):.2f}/10.0")
        print(f"Novelty Score:          {metrics.get('novelty_score', 0):.2f}/10.0")
        print(f"Citation Score:         {metrics.get('citation_score', 0):.2f}/10.0")
        print(f"Writing Quality:        {metrics.get('writing_quality_score', 0):.2f}/10.0")
        print(f"Reproducibility:        {metrics.get('reproducibility_score', 0):.2f}/10.0")

    # Display strengths and weaknesses
    print(f"\n{'='*70}")
    print("REVIEW SUMMARY")
    print(f"{'='*70}")

    if state.strengths:
        print(f"\nStrengths:")
        for strength in state.strengths[:5]:
            print(f"  + {strength}")

    if state.weaknesses:
        print(f"\nWeaknesses:")
        for weakness in state.weaknesses[:5]:
            print(f"  - {weakness}")

    # Display reviewer comments
    if state.reviewer_comments:
        print(f"\nReviewer Comments:")
        for comment in state.reviewer_comments:
            print(f"  • {comment}")

    # Display revision suggestions if applicable
    if state.decision in ["MAJOR_REVISION", "MINOR_REVISION"] and state.revision_suggestions:
        print(f"\nRevision Suggestions:")
        for i, suggestion in enumerate(state.revision_suggestions, 1):
            print(f"  {i}. {suggestion}")

    print(f"\n{'='*70}")
    print("Email notification sent to reviewers")
    print(f"{'='*70}\n")


def run_demo(max_workers: int = 5):
    """Run demo with sample paper"""
    print("\n" + "="*70)
    print("DEMO MODE - Academic Paper Reviewer")
    print("="*70)
    print("This will review a sample academic paper with mock data.")
    print("\nExample: Machine Learning Research Paper")

    # Demo paper
    paper_title = "A Novel Approach to Deep Learning Optimization"
    paper_content = get_sample_paper()
    conference = "International Conference on Machine Learning (ICML)"

    print(f"\nReviewing: {paper_title}\n")

    review_paper(paper_title, paper_content, conference, max_workers)


def interactive_mode():
    """Interactive mode for paper review"""
    print("\n" + "="*70)
    print("Academic Paper Reviewer - Multi-Agent Peer Review System")
    print("="*70)
    print("\n1. Review Paper")
    print("2. Run Demo")
    print("0. Exit")

    choice = input("\nSelect option (0-2): ").strip()

    if choice == "0":
        print("Goodbye!")
        return

    elif choice == "1":
        paper_title = input("Enter paper title: ").strip()
        paper_file = input("Enter paper file path (or press Enter for sample): ").strip()
        conference = input("Enter conference/journal name: ").strip()
        max_workers_str = input("Enter max workers (default 5): ").strip()

        try:
            max_workers = int(max_workers_str) if max_workers_str else 5
            paper_content = ""
            if paper_file:
                with open(paper_file, 'r') as f:
                    paper_content = f.read()
            else:
                paper_content = get_sample_paper()

            review_paper(paper_title, paper_content, conference, max_workers)
        except Exception as e:
            print(f"ERROR: {e}")

    elif choice == "2":
        max_workers_str = input("Enter max workers (default 5): ").strip()
        max_workers = int(max_workers_str) if max_workers_str else 5
        run_demo(max_workers)

    else:
        print("ERROR: Invalid choice")


def extract_abstract(paper_content: str) -> str:
    """Extract abstract from paper content"""
    # Simple extraction - look for "Abstract" section
    content_lower = paper_content.lower()
    if "abstract" in content_lower:
        start_idx = content_lower.index("abstract")
        # Take next 500 characters as abstract
        abstract_section = paper_content[start_idx:start_idx + 600]
        lines = abstract_section.split('\n')
        return ' '.join(lines[1:4])  # Skip "Abstract" header

    # Return first paragraph if no abstract found
    paragraphs = paper_content.split('\n\n')
    return paragraphs[0] if paragraphs else paper_content[:500]


def get_sample_paper() -> str:
    """Get sample paper content"""
    return """
A Novel Approach to Deep Learning Optimization

Authors: John Smith, Jane Doe, Bob Johnson

ABSTRACT

This paper presents a novel approach to optimizing deep learning models through adaptive
learning rate scheduling combined with momentum-based gradient descent. Our method
demonstrates significant improvements over existing approaches, achieving state-of-the-art
results on multiple benchmark datasets. We provide comprehensive experimental validation
and theoretical analysis of our proposed algorithm.

INTRODUCTION

Deep learning has revolutionized many fields in recent years. However, training deep
neural networks remains challenging due to optimization difficulties. Prior work has
explored various optimization techniques including Adam, SGD, and RMSprop. Our work
builds upon these foundations while introducing novel contributions.

METHODOLOGY

We propose an adaptive learning rate schedule that dynamically adjusts based on training
dynamics. Our experimental setup includes:
- Dataset: ImageNet, CIFAR-10, MNIST
- Hardware: NVIDIA A100 GPUs
- Framework: PyTorch 1.10
- Hyperparameters: Learning rate 0.001, batch size 128

Our statistical analysis uses significance testing with p-values < 0.05. We employ
control groups and baseline comparisons to validate our approach.

RELATED WORK

Significant prior work exists in optimization for deep learning (Smith et al., 2020;
Doe & Johnson, 2019). Recent advances include adaptive methods (Brown, 2021) and
momentum-based approaches (Wilson et al., 2018). Compared to previous methods, our
approach offers improved convergence rates.

EXPERIMENTAL RESULTS

Our experiments demonstrate consistent improvements across all benchmark datasets.
Statistical significance was verified through extensive testing. Results show 15%
improvement over baseline methods with confidence intervals indicating robust performance.

Code and data are available at: github.com/example/novel-optimization

DISCUSSION

The results validate our hypothesis that adaptive learning rates combined with momentum
lead to better optimization. Limitations include computational overhead and sensitivity
to hyperparameters. Future work could explore extensions to other architectures.

CONCLUSION

We presented a novel optimization approach for deep learning that achieves state-of-the-art
results. Our method is reproducible, with code and data publicly available. This work
opens new directions for optimization research.

REFERENCES

[1] Smith, A., et al. (2020). Optimization Methods in Deep Learning. ICML.
[2] Doe, J., Johnson, B. (2019). Adaptive Learning Rates. NeurIPS.
[3] Brown, C. (2021). Modern Optimization Techniques. JMLR.
[4] Wilson, P., et al. (2018). Momentum-Based Methods. ICLR.
[5] Anderson, M. (2017). Deep Learning Foundations. MIT Press.
[6] Lee, S., Kim, H. (2020). Neural Network Training. CVPR.
[7] Garcia, R. (2019). Convergence Analysis. PAMI.
[8] Chen, X., et al. (2021). Benchmark Datasets. arXiv.
[9] Taylor, D. (2018). Gradient Descent Variations. ICML.
[10] Martinez, L. (2020). Optimization Theory. Springer.
"""


if __name__ == "__main__":
    main()
